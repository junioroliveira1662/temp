import importlib

def test_agent_smoke():
    mod = importlib.import_module("agents.starter_agent.agent")
    assert hasattr(mod, "root_agent")
    assert getattr(mod, "root_agent").name == "starter_agent"