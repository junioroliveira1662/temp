import pytest
from your_agent.tools.sample_tool import ping

@pytest.mark.asyncio
async def test_ping():
    res = await ping("hello")
    assert res["status"] == "ok"
    assert res["echo"] == "hello"