# ADK + uv Starter (Python)

Estrutura de projeto pronta para **Google ADK (Agent Development Kit)** usando **layout `src/`** e **uv** para gerenciar ambiente, dependências e lockfile.

## Requisitos
- Python 3.11+
- [uv](https://docs.astral.sh/uv/reference/cli/)

## Primeiros passos (usando `uv`)

```bash
# 1) criar/ativar ambiente e instalar dependências (inclui grupo dev)
uv venv
uv sync --group dev

# 2) instalar o pacote local em modo editável (para importar 'your_agent')
uv pip install -e .

# 3) (Gemini) configurar credenciais
#   Opção A: Google AI Studio
export GOOGLE_API_KEY="sua_api_key"
#   Opção B: Vertex AI
# export GOOGLE_GENAI_USE_VERTEXAI=TRUE
# export GOOGLE_CLOUD_PROJECT="seu_projeto"
# export GOOGLE_CLOUD_LOCATION="us-central1"
```

> Dica: `uv lock` gera/atualiza o `uv.lock` (adicione ao versionamento).

## Rodar seu agente

Este template já inclui um agente em `agents/starter_agent` com duas tools de exemplo.
Você pode rodar em **CLI** ou na **Web UI** do ADK:

```bash
# CLI (interativo)
uv run adk run agents/starter_agent

# Web UI (dev)
uv run adk web agents
# acesse http://localhost:8000 e selecione "starter_agent"
```

## Estrutura

```text
adk-uv-starter/
├─ pyproject.toml
├─ README.md
├─ .gitignore
├─ .pre-commit-config.yaml
├─ agents/
│  └─ starter_agent/
│     ├─ __init__.py
│     └─ agent.py                # define `root_agent`
├─ src/
│  └─ your_agent/
│     ├─ __init__.py
│     ├─ prompts/
│     │  └─ system.md
│     ├─ tools/
│     │  └─ sample_tool.py
│     └─ observability/
│        └─ setup.py
├─ tests/
│  ├─ unit/
│  │  └─ test_sample_tool.py
│  └─ integration/
│     └─ test_agent_smoke.py
└─ scripts/
   ├─ dev.sh
   └─ run_local.sh
```

## Qualidade de código

```bash
uv run pre-commit install
uv run pre-commit run -a
uv run ruff check .
uv run black --check .
uv run mypy src
uv run pytest
```

## Notas
- Para usar modelos Gemini com ADK, configure `GOOGLE_API_KEY` (AI Studio) **ou** as variáveis do Vertex AI.
- Para paralelismo de tools, escreva funções `async def` e use clientes não-bloqueantes (ex.: `httpx.AsyncClient`).
- Use `adk web` para uma experiência de desenvolvimento com UI.