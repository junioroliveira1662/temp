from .agent import root_agent  # facilita a descoberta pelo ADK CLI
