from pathlib import Path

from google.adk.agents import LlmAgent
from google.adk.apps import App
from google.adk.plugins import ReflectAndRetryToolPlugin
from google.adk.tools import FunctionTool

# Suas tools (async) residem no pacote em src/
# Garanta que o projeto esteja instalado em modo editável: `uv pip install -e .`
from your_agent.tools.sample_tool import ping, risky_operation

# Instruções básicas (poderia carregar de arquivo)
SYSTEM_INSTRUCTION = "Você é um assistente de exemplo. Use tools em paralelo quando apropriado."

# Define o agente raiz (descoberto pelo CLI `adk run` / `adk web`)
root_agent = LlmAgent(
    name="starter_agent",
    model="gemini-2.5-flash",
    instruction=SYSTEM_INSTRUCTION,
    tools=[
        # Envólucro que expõe as funções como ferramentas ADK
        FunctionTool(ping),
        FunctionTool(
            risky_operation,
            # Confirmação humana para valores altos
            require_confirmation=lambda amount, **kwargs: float(amount) > 1000.0,
        ),
    ],
)

# Opcional: definir um App para aplicar plugins (ex.: autoretry de tools)
app = App(
    name="starter_app",
    root_agent=root_agent,
    plugins=[ReflectAndRetryToolPlugin(max_retries=2)],
)

# Observação: `adk run agents/starter_agent` usa `root_agent`.
# Já `adk web agents` carrega todos os agentes do diretório.