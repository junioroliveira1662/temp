from typing import Annotated, Dict, Any

async def ping(message: Annotated[str, "Texto a ecoar"]) -> Dict[str, Any]:
    """Retorna a própria mensagem para verificação de fluxo."""
    return {"status": "ok", "echo": message}

async def risky_operation(amount: Annotated[float, "Valor monetário"], action: Annotated[str, "Nome da ação"]) -> Dict[str, Any]:
    """Operação fictícia que poderia exigir confirmação humana dependendo do valor."""
    # Em um cenário real, você faria a operação aqui.
    return {"status": "ok", "operation": action, "amount": amount}