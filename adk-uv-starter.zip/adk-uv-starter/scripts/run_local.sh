#!/usr/bin/env bash
set -euo pipefail
uv run adk run agents/starter_agent