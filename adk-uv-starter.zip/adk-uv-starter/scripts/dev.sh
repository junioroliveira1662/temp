#!/usr/bin/env bash
set -euo pipefail
# Sincroniza dependências (inclui grupo dev), instala pacote local e sobe a Web UI
uv sync --group dev
uv pip install -e .
uv run adk web agents