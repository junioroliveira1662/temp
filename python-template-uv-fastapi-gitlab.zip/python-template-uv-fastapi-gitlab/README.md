# 🐍 Python Template (FastAPI + uv)

Template moderno com **FastAPI** e **uv**, incluindo qualidade de código, Docker e CI/CD para GitLab.

## 🚀 Stack
- Gerenciador: **uv**
- Web: **FastAPI** + **Uvicorn**
- Config: `pydantic-settings` + `.env`
- Qualidade: **ruff**, **black**, **isort**, **mypy**, **pytest** (+cov), **bandit**
- Hooks: **pre-commit**
- Observabilidade: **logging JSON**
- Container: **Dockerfile**
- CI/CD: **GitLab CI**

## ▶️ Como usar (local)
```bash
# Instalar dependências (cria venv automaticamente)
uv sync --all-extras --dev

# Ativar pre-commit
uv run pre-commit install

# Rodar testes
uv run pytest

# Subir API
uv run uvicorn app_template.main:app --reload
```

Acesse: http://localhost:8000/docs

## 🐳 Docker
```bash
docker build -t python-template:dev .
docker run -p 8000:8000 python-template:dev
```

## 🔁 GitLab CI
Pipeline padrão com lint, tipos, testes e segurança.
Edite `.gitlab-ci.yml` conforme necessário.
