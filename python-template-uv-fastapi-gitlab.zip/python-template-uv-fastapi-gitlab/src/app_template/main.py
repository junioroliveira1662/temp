from fastapi import FastAPI
from .core.config import settings
from .core.logger import get_logger
from .routers import health

app = FastAPI(title=settings.app_name)

app.include_router(health.router, prefix="/health", tags=["health"])

logger = get_logger()

@app.get("/", tags=["root"])
def root():
    logger.info("Root endpoint hit", extra={"event": "root_call"})
    return {"app": settings.app_name, "status": "ok"}
