from fastapi import APIRouter

router = APIRouter()

@router.get("/live")
def live():
    return {"status": "live"}

@router.get("/ready")
def ready():
    # Inserir aqui checagens (DB, fila, etc.) se necessário
    return {"status": "ready"}
