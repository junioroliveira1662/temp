# lib_template

Biblioteca Python reutilizável.

## Instalação
```bash
uv add lib_template
```

## Uso
```python
from lib_template.core import soma
print(soma(1, 2))
```
