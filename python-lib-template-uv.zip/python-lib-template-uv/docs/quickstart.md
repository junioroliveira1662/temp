# Guia Rápido

1. Instale dependências
```bash
uv sync --all-extras --dev
```

2. Execute testes
```bash
uv run pytest
```

3. Suba a documentação local
```bash
uv run mkdocs serve
```
