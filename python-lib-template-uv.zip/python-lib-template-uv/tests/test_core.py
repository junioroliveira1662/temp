from lib_template.core import soma, get_version

def test_soma():
    assert soma(2, 3) == 5

def test_version():
    assert isinstance(get_version(), str)
    assert get_version() == "0.1.0"
