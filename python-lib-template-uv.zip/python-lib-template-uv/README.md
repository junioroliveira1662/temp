# 📦 lib_template

Template de **biblioteca Python** pronto para reutilização e publicação futura, usando **uv** como gerenciador,
com **qualidade**, **testes** e **documentação** via **mkdocs**.

## 🚀 Como começar (local com uv)

```bash
uv sync --all-extras --dev
uv run pre-commit install
uv run pytest
```

## ✍️ Como usar a biblioteca

```python
from lib_template.core import soma, get_version

print(soma(2, 3))         # 5
print(get_version())      # "0.1.0"
```

## 📚 Documentação (mkdocs)

```bash
uv run mkdocs serve
# Abra http://127.0.0.1:8000
```

## 🧪 Testes
```bash
uv run pytest
```

## 🔁 CI (GitLab)
- Lint: ruff + black + isort
- Tipagem: mypy
- Testes: pytest + coverage
- Build do pacote
> Publicação no PyPI **não** está configurada neste template (pode ser adicionada depois).
