"""Core module da biblioteca."""

from .utils import version_info


def soma(a: int, b: int) -> int:
    """Soma dois números inteiros."""
    return a + b


def get_version() -> str:
    """Retorna a versão atual da biblioteca."""
    return version_info()
