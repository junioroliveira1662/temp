"""Top-level package for lib_template."""
__all__ = ["core", "utils"]
__version__ = "0.1.0"
