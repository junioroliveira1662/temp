"""Utilidades internas da biblioteca."""

def version_info() -> str:
    return "0.1.0"
