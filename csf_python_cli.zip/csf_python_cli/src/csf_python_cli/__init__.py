"""CSF Python CLI - Gerador de projetos."""
