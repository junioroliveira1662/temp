import typer
import subprocess
import shutil
import os
from pathlib import Path
from rich import print

app = typer.Typer(help="CLI para gerar projetos Python (lib/api) a partir de templates GitLab.")

TEMPLATES = {
    "api": "https://gitlab.com/i8-solutions/python-template-api.git",
    "lib": "https://gitlab.com/i8-solutions/python-template-lib.git",
}

def run(cmd, cwd=None):
    result = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"[red]Erro:[/red] {result.stderr}")
        raise typer.Exit(1)
    return result.stdout.strip()

@app.command()
def new(
    tipo: str = typer.Argument(..., help="Tipo de projeto (api ou lib)"),
    nome: str = typer.Argument(..., help="Nome do novo projeto"),
    branch: str = typer.Option("main", "--branch", "-b", help="Branch do template"),
    output: Path = typer.Option(Path("."), "--output", "-o", help="Diretório de destino"),
):
    """
    Cria um novo projeto baseado em um template GitLab (api/lib).
    """

    if tipo not in TEMPLATES:
        print("[red]❌ Tipo inválido. Use 'api' ou 'lib'.[/red]")
        raise typer.Exit(1)

    repo_url = TEMPLATES[tipo]

    # Autenticação com token (para repositórios privados)
    token = os.getenv("GITLAB_TOKEN")
    if token and repo_url.startswith("https://"):
        repo_url = repo_url.replace("https://", f"https://oauth2:{token}@")

    dest_dir = output / nome
    if dest_dir.exists():
        print(f"[yellow]⚠️ O diretório '{dest_dir}' já existe.[/yellow]")
        raise typer.Exit(1)

    print(f"[cyan]📥 Clonando template '{tipo}' de {repo_url} (branch {branch})...[/cyan]")
    run(f"git clone -b {branch} {repo_url} {dest_dir}")

    # Remove .git
    git_dir = dest_dir / ".git"
    if git_dir.exists():
        shutil.rmtree(git_dir)

    # Substituir nomes
    print("[cyan]🧱 Renomeando referências internas...[/cyan]")
    for root, _, files in os.walk(dest_dir):
        for file in files:
            path = Path(root) / file
            if path.suffix in [".py", ".toml", ".md", ".yml"]:
                text = path.read_text(encoding="utf-8")
                text = text.replace("app_template", nome)
                text = text.replace("lib_template", nome)
                text = text.replace("python-template", nome)
                path.write_text(text, encoding="utf-8")

    print(f"[green]✅ Projeto '{nome}' criado com sucesso em {dest_dir.resolve()}![/green]")
    print("[blue]👉 Próximos passos:")
    print(f"   cd {nome}")
    print("   uv sync --all-extras --dev")
    print("   uv run pre-commit install[/blue]")

if __name__ == "__main__":
    app()
