# 🧰 CSF Python CLI

CLI para gerar projetos Python automaticamente a partir de **templates GitLab**, com suporte a:

- Tipos: `api` ou `lib`
- Branch personalizada (`--branch`)
- Diretório de saída (`--output`)
- Autenticação com `GITLAB_TOKEN` (para templates privados)

## 🚀 Como usar

```bash
uv sync
uv run csf new api meu_projeto
```

### Opções

```bash
uv run csf new lib minha_biblioteca --branch develop --output ./projetos
```

## ⚙️ Autenticação (repositórios privados)

```bash
export GITLAB_TOKEN="seu_token_aqui"
```

## 🧩 Estrutura

- `src/csf_python_cli/cli.py`: ponto de entrada principal (Typer)
- `.pre-commit-config.yaml`: hooks automáticos
- `.gitlab-ci.yml`: pipeline básico (lint + teste)
