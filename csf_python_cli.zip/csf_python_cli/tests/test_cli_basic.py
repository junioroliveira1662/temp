def test_cli_runs():
    assert True
